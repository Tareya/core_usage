#!/usr/bin/env python3
# -*- coding:utf8 -*-


from distutils.core import setup

setup(
    name='basic_usage',
    version='v1.0',
    author='Tareya',
    author_email='Tareya@163.com',
    packages=['core_usage'],
    py_modules=['nginx_config_analysis', 'k8s_project_analysis', 'mysql_operator']
)