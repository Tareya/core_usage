#!/usr/bin/env python3
# -*- coding:utf8 -*-


from distutils.core import setup

setup(
    name='core_usage',
    version='v1.1',
    author='Tareya',
    author_email='Tareya@163.com',
    packages=['core_usage'],
)